from controller import Robot

def run_robot():
    # Create the Robot instance
    robot = Robot()

    # Get simulation time step
    timestep = int(robot.getBasicTimeStep())

    # Get motor device
    motor = robot.getDevice('motor1')

    # Define the amplitude and speed of the oscillation
    amplitude = 0.5  # radian
    speed = 0.1  # radians per timestep

    # Set initial position and direction
    position = 0
    direction = 1

    # Main control loop
    while robot.step(timestep) != -1:
        # Update position
        position += direction * speed
        
        # Change direction if limits are reached
        if position >= amplitude or position <= 0:
            direction *= -1
        
        # Set motor position
        motor.setPosition(position)

if __name__ == "__main__":
    run_robot()