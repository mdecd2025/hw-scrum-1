import math
deg = math.pi/180
print(90*deg)
print(55.12*deg)
print(90.53*deg)