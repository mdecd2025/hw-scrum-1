import math
deg = math.pi/180
print(90*deg)